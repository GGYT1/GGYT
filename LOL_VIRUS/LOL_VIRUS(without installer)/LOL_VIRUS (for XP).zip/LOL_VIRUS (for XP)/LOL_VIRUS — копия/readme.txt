Have some fun! Run app.bat!
Веселись! Запускай app.bat!